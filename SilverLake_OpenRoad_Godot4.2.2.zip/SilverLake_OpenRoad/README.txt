SILVER LAKE - OPEN ROAD   (Godot 4.2.2 stable)
==============================================

HOW TO RUN
1. Open Godot 4.2.2 -> Project Manager -> Import -> pick project.godot in this folder.
2. Let Godot import the assets the first time (the 10 MB tree pack takes a minute).
3. Press F5. Wait for the loading bar, then press any key.

If Godot says it cannot start Vulkan (older / integrated graphics):
   Project > Project Settings > Rendering > Renderer > Rendering Method = "gl_compatibility", restart.
   Everything still runs; SSAO / reflections / volumetric fog are simply skipped in that mode.

CONTROLS
 W / Up        throttle            S / Down   brake, then reverse
 A D / arrows  steer               SPACE      handbrake (drift!)
 C             camera: chase / front / side (also: drag mouse to orbit, wheel to zoom)
 T             time of day         R          respawn on the road
 ENTER         start / cancel race F1         graphics quality Low/Medium/High/Ultra
 H             hide HUD            Gamepad: left stick, triggers, X = handbrake, right stick = camera

MAKE IT RUN FASTER OR LOOK BETTER
 - Press F1 in game (default is High). Scenery density applies on the next launch.
 - scripts/world.gd top: TREE_COUNT, BUSH_COUNT, ROCK_COUNT.
 - scripts/car.gd top:  POWER, MAX_DRIVE, MU_ROAD, LAT_RESP, SPRING_K ... (handling feel).
 - If the car drives backwards, set MODEL_YAW to PI / 2.0 in scripts/car.gd.

YOUR ASSETS (used unchanged, byte-identical to your uploads)
 assets/mclaren_720s.glb
 assets/low_poly_forest_tree_pack.glb
 assets/tree_low_poly_lowpoly.glb
The terrain / road / cloud textures in assets/textures were generated for this project.

CREDITS (CC BY 4.0)
 "2017 Mclaren 720s" by _Sheep19
 "Low Poly Forest Tree Pack" by 99.Miles
 "Tree low poly" by 00amza
