extends Camera3D
# Chase camera: drag with the mouse (or right stick) to orbit, wheel to zoom, C cycles chase / front / side.

signal view_changed(label: String)

const VIEWS = [0.0, PI, PI * 0.5]
const VIEW_NAMES = ["Chase camera", "Front camera", "Side camera"]

var target: RigidBody3D
var world
var yaw_off := 0.0
var pit := 0.0
var zoom := 1.0
var base_yaw := 0.0
var idle := 9.0
var dragging := false
var view_i := 0
var smooth_f := Vector3(0.0, 0.0, -1.0)


func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        var mb := event as InputEventMouseButton
        if mb.button_index == MOUSE_BUTTON_LEFT or mb.button_index == MOUSE_BUTTON_RIGHT:
            dragging = mb.pressed
            idle = 0.0
        elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
            zoom = clampf(zoom * 0.9, 0.5, 2.5)
        elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            zoom = clampf(zoom * 1.1, 0.5, 2.5)
    elif event is InputEventMouseMotion and dragging:
        var mm := event as InputEventMouseMotion
        yaw_off -= mm.relative.x * 0.006
        pit = clampf(pit + mm.relative.y * 0.004, -0.2, 1.1)
        idle = 0.0
    elif event is InputEventKey:
        var k := event as InputEventKey
        if k.pressed and not k.echo and k.keycode == KEY_C:
            next_view()


func next_view() -> void:
    view_i = (view_i + 1) % 3
    base_yaw = VIEWS[view_i]
    idle = 9.0
    view_changed.emit(VIEW_NAMES[view_i])


func _process(dt: float) -> void:
    if target == null:
        return
    var rx := Input.get_joy_axis(0, JOY_AXIS_RIGHT_X)
    var ry := Input.get_joy_axis(0, JOY_AXIS_RIGHT_Y)
    if absf(rx) > 0.2 or absf(ry) > 0.2:
        yaw_off -= rx * dt * 2.5
        pit = clampf(pit + ry * dt * 1.5, -0.2, 1.1)
        idle = 0.0
    var tp := target.global_position
    var f := -target.global_transform.basis.z
    f.y = 0.0
    if f.length() > 0.01:
        f = f.normalized()
        smooth_f = smooth_f.lerp(f, 1.0 - exp(-dt * 3.2)).normalized()
    var spd := target.linear_velocity.length()
    if not dragging:
        idle += dt
        if idle > 2.5:
            yaw_off += angle_difference(yaw_off, base_yaw) * (1.0 - exp(-dt * 2.5))
            pit *= 1.0 - minf(dt * 2.5, 1.0)
    var off_f := smooth_f.rotated(Vector3.UP, yaw_off)
    var dist := (6.4 + spd * 0.018) * zoom
    var el := 0.2 + pit
    var pos := tp - off_f * dist * cos(el) + Vector3.UP * (1.25 + dist * sin(el))
    var blend := 1.0 - exp(-dt * (22.0 if dragging else 8.0))
    var gp := global_position.lerp(pos, blend)
    if world != null:
        gp.y = maxf(gp.y, maxf(world.height_at(gp.x, gp.z), 0.0) + 0.9)
    global_position = gp
    var ahead := clampf(1.0 - absf(angle_difference(0.0, yaw_off)) / 0.8, 0.0, 1.0) * 4.0
    look_at(tp + Vector3.UP * 0.9 + smooth_f * ahead, Vector3.UP)
    fov = lerpf(fov, 68.0 + minf(spd, 80.0) * 0.22, 1.0 - exp(-dt * 3.0))
    var shake := clampf((spd - 45.0) / 40.0, 0.0, 1.0)
    h_offset = randf_range(-1.0, 1.0) * 0.015 * shake
    v_offset = randf_range(-1.0, 1.0) * 0.015 * shake
