extends Node3D
# A closed-circuit race around the island: pass every glowing gate in order, then cross the line.

signal message(text: String)

const CP_COUNT := 12
var world
var car
var active := false
var next_cp := 1
var t := 0.0
var countdown := 0.0
var best := 0.0
var cp_idx: Array = []
var gate: MeshInstance3D
var cfg := ConfigFile.new()


func setup(w, c) -> void:
    world = w
    car = c
    var n: int = world.road_pts.size()
    for i in CP_COUNT:
        cp_idx.append(int(i * n / CP_COUNT))
    var cyl := CylinderMesh.new()
    cyl.top_radius = 7.5
    cyl.bottom_radius = 7.5
    cyl.height = 70.0
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.albedo_color = Color(1.0, 0.72, 0.15, 0.3)
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    cyl.material = m
    gate = MeshInstance3D.new()
    gate.mesh = cyl
    gate.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    gate.visible = false
    add_child(gate)
    if cfg.load("user://silverlake.cfg") == OK:
        best = float(cfg.get_value("race", "best", 0.0))


func gate_pos() -> Vector3:
    return world.road_pts[cp_idx[next_cp % CP_COUNT]]


func start() -> void:
    active = true
    next_cp = 1
    t = 0.0
    countdown = 3.4
    car.input_enabled = false
    car.place_at(world.road_pts[cp_idx[0]] + Vector3(0.0, 0.9, 0.0), world.road_dirs[cp_idx[0]])
    gate.visible = true
    gate.global_position = gate_pos() + Vector3(0.0, 30.0, 0.0)
    message.emit("Race started - follow the golden beam")


func stop() -> void:
    active = false
    gate.visible = false


func fmt(sec: float) -> String:
    return "%d:%02d.%03d" % [int(sec) / 60, int(sec) % 60, int((sec - floorf(sec)) * 1000.0)]


func _physics_process(dt: float) -> void:
    if not active:
        return
    if countdown > 0.0:
        countdown -= dt
        if countdown <= 0.0:
            car.input_enabled = true
            message.emit("GO!")
        return
    t += dt
    var gp := gate_pos()
    var cp: Vector3 = car.global_position
    if Vector2(cp.x - gp.x, cp.z - gp.z).length() < 16.0 and absf(cp.y - gp.y) < 25.0:
        next_cp += 1
        if next_cp > CP_COUNT:
            active = false
            gate.visible = false
            var txt := "FINISH  " + fmt(t)
            if best <= 0.0 or t < best:
                best = t
                cfg.set_value("race", "best", best)
                cfg.save("user://silverlake.cfg")
                txt += "  - NEW BEST!"
            message.emit(txt)
        else:
            gate.global_position = gate_pos() + Vector3(0.0, 30.0, 0.0)
            message.emit("Checkpoint %d / %d" % [next_cp - 1, CP_COUNT - 1])
