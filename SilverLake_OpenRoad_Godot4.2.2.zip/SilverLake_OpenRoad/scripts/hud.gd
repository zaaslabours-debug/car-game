extends Control
# Minimal racing HUD: speed / gear / rev arc, mini-map, skill chain, race timer, checkpoint arrow.

const MAP_R := 112.0
const WORLD_R := 700.0

var car
var cam
var race
var world
var font: Font
var toast_text := ""
var toast_t := 0.0
var bank_text := ""
var bank_t := 0.0
var map_pts := PackedVector2Array()


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    font = ThemeDB.fallback_font


func setup(w) -> void:
    world = w
    for p in world.road_pts:
        map_pts.append(Vector2(p.x, p.z) * (MAP_R / WORLD_R))
    if map_pts.size() > 0:
        map_pts.append(map_pts[0])


func show_toast(text: String) -> void:
    toast_text = text
    toast_t = 2.4


func show_bank(points: int) -> void:
    bank_text = "+%d SKILL" % points
    bank_t = 2.2


func _process(dt: float) -> void:
    toast_t -= dt
    bank_t -= dt
    queue_redraw()


func _txt(text: String, pos: Vector2, fsize: int, col: Color, width: float = -1.0, align: int = HORIZONTAL_ALIGNMENT_CENTER) -> void:
    draw_string(font, pos + Vector2(2.0, 2.0), text, align, width, fsize, Color(0, 0, 0, col.a * 0.55))
    draw_string(font, pos, text, align, width, fsize, col)


func _draw() -> void:
    if car == null:
        return
    var w := size.x
    var h := size.y
    # ---- speedometer
    var c := Vector2(w - 170.0, h - 150.0)
    var f := clampf((car.rpm - 900.0) / 7000.0, 0.0, 1.0)
    draw_arc(c, 104.0, deg_to_rad(135.0), deg_to_rad(405.0), 64, Color(1, 1, 1, 0.14), 9.0, true)
    var col := Color(0.55, 0.85, 1.0).lerp(Color(1.0, 0.25, 0.2), clampf((f - 0.78) / 0.22, 0.0, 1.0))
    draw_arc(c, 104.0, deg_to_rad(135.0), deg_to_rad(135.0 + 270.0 * f), 64, col, 9.0, true)
    _txt(str(int(car.speed * 3.6)), c + Vector2(-90.0, 26.0), 74, Color.WHITE, 180.0)
    _txt("KM/H", c + Vector2(-90.0, 54.0), 16, Color(1, 1, 1, 0.7), 180.0)
    var g := "R" if car.v_long < -0.5 else str(car.gear)
    _txt(g, c + Vector2(-90.0, -34.0), 42, Color(1.0, 0.85, 0.3), 180.0)
    # ---- mini-map
    var mc := Vector2(150.0, h - 150.0)
    draw_circle(mc, MAP_R + 6.0, Color(0, 0, 0, 0.45))
    var pts := PackedVector2Array()
    for p in map_pts:
        pts.append(mc + p)
    if pts.size() > 1:
        draw_polyline(pts, Color(1, 1, 1, 0.75), 3.0, true)
    if race != null and race.active:
        var gp: Vector3 = race.gate_pos()
        draw_circle(mc + Vector2(gp.x, gp.z) * (MAP_R / WORLD_R), 6.0, Color(1.0, 0.75, 0.2))
    var cp: Vector3 = car.global_position
    var me := mc + Vector2(cp.x, cp.z) * (MAP_R / WORLD_R)
    var fw := Vector2(-car.global_transform.basis.z.x, -car.global_transform.basis.z.z).normalized()
    draw_colored_polygon(PackedVector2Array([me + fw * 11.0, me + fw.rotated(2.5) * 8.0, me + fw.rotated(-2.5) * 8.0]), Color(0.3, 0.85, 1.0))
    # ---- skill chain
    if car.drift_score > 0.0:
        _txt("DRIFT  %d   x%.1f" % [int(car.drift_score * car.drift_mult), car.drift_mult], Vector2(0.0, 120.0), 40, Color(1.0, 0.85, 0.25), w)
    if bank_t > 0.0:
        _txt(bank_text, Vector2(0.0, 175.0), 52, Color(0.5, 1.0, 0.55, clampf(bank_t, 0.0, 1.0)), w)
    _txt("SKILL  %d" % car.total_skill, Vector2(w - 250.0, 38.0), 24, Color(1, 1, 1, 0.85), 230.0, HORIZONTAL_ALIGNMENT_RIGHT)
    # ---- race
    if race != null:
        if race.active:
            _txt(race.fmt(race.t), Vector2(w - 250.0, 72.0), 36, Color.WHITE, 230.0, HORIZONTAL_ALIGNMENT_RIGHT)
            _txt("CHECKPOINT %d / %d" % [mini(race.next_cp, race.CP_COUNT), race.CP_COUNT], Vector2(w - 250.0, 100.0), 18, Color(1, 0.85, 0.3), 230.0, HORIZONTAL_ALIGNMENT_RIGHT)
            if race.countdown > 0.0:
                _txt(str(int(ceil(race.countdown - 0.4))), Vector2(0.0, h * 0.4), 150, Color(1.0, 0.85, 0.3), w)
            elif cam != null:
                var to: Vector3 = race.gate_pos() - cam.global_position
                to.y = 0.0
                var cf: Vector3 = -cam.global_transform.basis.z
                cf.y = 0.0
                var ang: float = cf.signed_angle_to(to, Vector3.UP)
                var ac := Vector2(w * 0.5, 90.0)
                var rot := -ang
                draw_colored_polygon(PackedVector2Array([ac + Vector2(0, -24).rotated(rot), ac + Vector2(-15, 14).rotated(rot), ac + Vector2(15, 14).rotated(rot)]), Color(1.0, 0.8, 0.2, 0.9))
        else:
            _txt("ENTER  -  start race", Vector2(0.0, h - 38.0), 22, Color(1, 1, 1, 0.8), w)
            if race.best > 0.0:
                _txt("BEST  " + race.fmt(race.best), Vector2(w - 250.0, 72.0), 26, Color(1, 1, 1, 0.8), 230.0, HORIZONTAL_ALIGNMENT_RIGHT)
    if toast_t > 0.0:
        _txt(toast_text, Vector2(0.0, 52.0), 30, Color(1, 1, 1, clampf(toast_t, 0.0, 1.0)), w)
