extends RigidBody3D
# Rear-wheel-drive supercar with raycast suspension, load-based tyre grip and a friction circle.
# Heavy by design: 1450 kg, slow steering build-up, real weight transfer. Push the throttle in a
# corner and the rear lets go - that is where the drift points come from.

signal drift_banked(points: int)
signal drift_lost()

const MODEL_PATH := "res://assets/mclaren_720s.glb"
const MODEL_YAW := -PI / 2.0         # if the car drives backwards, change this to PI / 2.0
const MODEL_LENGTH := 4.6
const RIDE := 0.57                   # body centre height above the ground at rest
const WHEEL_R := 0.34
const REST := 0.30
const TRAVEL := 0.22
const SPRING_K := 52000.0
const SPRING_C := 4200.0
const MAX_STEER := 0.60
const POWER := 270000.0              # watts at the wheels
const MAX_DRIVE := 9500.0            # newtons of traction at the rear axle
const BRAKE_FORCE := 17000.0
const DRAG := 0.5
const DOWNFORCE := 0.35
const LAT_RESP := 9.0
const MU_ROAD := 1.6
const MU_GRASS := 1.0
const MU_SAND := 0.8
const GEAR_TOP = [16.0, 29.0, 42.0, 55.0, 67.0, 78.0, 92.0]

var input_enabled := false
var rays: Array = []
var anchors := [Vector3(-0.88, 0.0, -1.38), Vector3(0.88, 0.0, -1.38), Vector3(-0.88, 0.0, 1.42), Vector3(0.88, 0.0, 1.42)]
var last_len := [0.3, 0.3, 0.3, 0.3]
var steer_in := 0.0
var throttle_in := 0.0
var brake_in := 0.0
var steer := 0.0
var throttle := 0.0
var brake := 0.0
var handbrake := false
var speed := 0.0
var v_long := 0.0
var slip := 0.0
var gear := 1
var rpm := 1000.0
var shift_cut := 0.0
var grounded_count := 0
var wheel_slip := 0.0
var visual: Node3D
var front_pivot: Node3D
var rear_pivot: Node3D
var spin := 0.0
var wheel_radius_vis := 0.33
var lights: Array = []
var engine_player: AudioStreamPlayer
var skid_player: AudioStreamPlayer
var smoke: Array = []
var smoke_sprite: Texture2D
var drifting := false
var drift_score := 0.0
var drift_time := 0.0
var drift_mult := 1.0
var drift_idle := 0.0
var total_skill := 0
var flipped_time := 0.0


func _ready() -> void:
    mass = 1450.0
    center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
    center_of_mass = Vector3(0.0, -0.25, 0.0)
    inertia = Vector3(2600.0, 3800.0, 1100.0)
    can_sleep = false
    continuous_cd = true
    angular_damp = 0.5
    contact_monitor = true
    max_contacts_reported = 4
    var pm := PhysicsMaterial.new()
    pm.friction = 0.1
    pm.bounce = 0.0
    physics_material_override = pm
    var cs := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(1.9, 0.7, 4.4)
    cs.shape = box
    cs.position = Vector3(0.0, 0.12, 0.0)
    add_child(cs)
    for a in anchors:
        var r := RayCast3D.new()
        r.position = a
        r.target_position = Vector3(0.0, -(REST + TRAVEL + WHEEL_R), 0.0)
        r.enabled = true
        r.collision_mask = 1
        add_child(r)
        rays.append(r)
    _build_visual()
    _build_lights()
    _build_audio()
    smoke_sprite = _soft_sprite()
    smoke.append(_make_smoke(Vector3(-0.88, -0.45, 1.42)))
    smoke.append(_make_smoke(Vector3(0.88, -0.45, 1.42)))
    body_entered.connect(_on_hit)


# ---------------------------------------------------------------- visuals
func _node_aabb(mi: Node3D) -> AABB:
    var inv := visual.global_transform.affine_inverse()
    return inv * mi.global_transform * mi.get_aabb()


func _aabb_of(root: Node) -> AABB:
    var out := AABB()
    var first := true
    for mi in root.find_children("*", "MeshInstance3D", true, false):
        if mi.mesh == null:
            continue
        var a: AABB = _node_aabb(mi)
        if first:
            out = a
            first = false
        else:
            out = out.merge(a)
    return out


func _build_visual() -> void:
    visual = Node3D.new()
    add_child(visual)
    visual.position = Vector3(0.0, -RIDE, 0.0)
    var res = load(MODEL_PATH)
    if res == null:
        push_warning("mclaren_720s.glb not found - using a placeholder box")
        var mi := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(1.9, 0.9, 4.4)
        mi.mesh = bm
        mi.position = Vector3(0.0, 0.5, 0.0)
        visual.add_child(mi)
        return
    var m: Node3D = res.instantiate()
    visual.add_child(m)
    m.rotation.y = MODEL_YAW
    var box := _aabb_of(m)
    var s := MODEL_LENGTH / maxf(box.size.x, box.size.z)
    m.scale = Vector3.ONE * s
    box = _aabb_of(m)
    var c := box.get_center()
    m.position = Vector3(-c.x, -box.position.y, -c.z)
    _tune_materials(m)
    _setup_wheels(m)


func _tune_materials(m: Node) -> void:
    var done := {}
    for mi in m.find_children("*", "MeshInstance3D", true, false):
        if mi.mesh == null:
            continue
        for s in mi.mesh.get_surface_count():
            var mat = mi.mesh.surface_get_material(s)
            if mat == null or not (mat is BaseMaterial3D):
                continue
            var id: int = mat.get_instance_id()
            if done.has(id):
                continue
            done[id] = true
            var nm := String(mat.resource_name)
            if nm == "body" or nm == "black_metallic" or nm == "silver":
                mat.clearcoat_enabled = true
                mat.clearcoat = 1.0
                mat.clearcoat_roughness = 0.04


func _setup_wheels(m: Node3D) -> void:
    var re := RegEx.new()
    re.compile("^tyres([._]\\d+)?$")
    var axles: Array = []
    for n in m.find_children("tyres*", "Node3D", true, false):
        if re.search(String(n.name)) != null:
            axles.append(n)
    if axles.size() < 2:
        push_warning("Could not find the two tyre nodes - wheels will not spin")
        return
    var za := _aabb_of(axles[0]).get_center().z
    var zb := _aabb_of(axles[1]).get_center().z
    var front: Node3D = axles[0] if za < zb else axles[1]
    var rear: Node3D = axles[1] if za < zb else axles[0]
    front_pivot = _make_pivot(front)
    rear_pivot = _make_pivot(rear)


func _make_pivot(node: Node3D) -> Node3D:
    var box := _aabb_of(node)
    var pv := Node3D.new()
    visual.add_child(pv)
    pv.position = box.get_center()
    node.reparent(pv, true)
    wheel_radius_vis = maxf(box.size.y * 0.5, 0.2)
    return pv


func _build_lights() -> void:
    for sx in [-0.7, 0.7]:
        var sl := SpotLight3D.new()
        sl.position = Vector3(sx, 0.05, -2.1)
        sl.rotation_degrees = Vector3(-4.0, 0.0, 0.0)
        sl.spot_range = 80.0
        sl.spot_angle = 32.0
        sl.light_energy = 6.0
        sl.visible = false
        add_child(sl)
        lights.append(sl)


func set_headlights(on: bool) -> void:
    for l in lights:
        l.visible = on


func _soft_sprite() -> Texture2D:
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
    g.offsets = PackedFloat32Array([0.0, 1.0])
    var t := GradientTexture2D.new()
    t.gradient = g
    t.fill = GradientTexture2D.FILL_RADIAL
    t.fill_from = Vector2(0.5, 0.5)
    t.fill_to = Vector2(1.0, 0.5)
    t.width = 64
    t.height = 64
    return t


func _make_smoke(local_pos: Vector3) -> GPUParticles3D:
    var p := GPUParticles3D.new()
    p.position = local_pos
    p.amount = 48
    p.lifetime = 1.8
    p.local_coords = false
    p.emitting = false
    var pm := ParticleProcessMaterial.new()
    pm.direction = Vector3(0.0, 1.0, 0.3)
    pm.spread = 30.0
    pm.initial_velocity_min = 1.0
    pm.initial_velocity_max = 3.0
    pm.gravity = Vector3(0.0, 0.5, 0.0)
    pm.scale_min = 1.4
    pm.scale_max = 3.0
    var ramp := Gradient.new()
    ramp.colors = PackedColorArray([Color(1, 1, 1, 0.55), Color(1, 1, 1, 0.0)])
    ramp.offsets = PackedFloat32Array([0.0, 1.0])
    var rt := GradientTexture1D.new()
    rt.gradient = ramp
    pm.color_ramp = rt
    p.process_material = pm
    var q := QuadMesh.new()
    q.size = Vector2(1.0, 1.0)
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    m.billboard_keep_scale = true
    m.vertex_color_use_as_albedo = true
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    m.albedo_texture = smoke_sprite
    m.albedo_color = Color(0.9, 0.9, 0.9, 1.0)
    q.material = m
    p.draw_pass_1 = q
    add_child(p)
    return p


# ---------------------------------------------------------------- audio (synthesised in code)
func _build_audio() -> void:
    engine_player = AudioStreamPlayer.new()
    engine_player.stream = _make_engine_wav()
    engine_player.volume_db = -8.0
    add_child(engine_player)
    engine_player.play()
    skid_player = AudioStreamPlayer.new()
    skid_player.stream = _make_skid_wav()
    skid_player.volume_db = -80.0
    add_child(skid_player)
    skid_player.play()


func _wav(data: PackedByteArray, n: int) -> AudioStreamWAV:
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = 22050
    w.stereo = false
    w.data = data
    w.loop_mode = AudioStreamWAV.LOOP_FORWARD
    w.loop_begin = 0
    w.loop_end = n
    return w


func _make_engine_wav() -> AudioStreamWAV:
    var n := 22050
    var data := PackedByteArray()
    data.resize(n * 2)
    var harm := [1.0, 0.9, 0.7, 0.55, 0.4, 0.3, 0.22, 0.15, 0.1, 0.06]
    for i in n:
        var t := float(i) / 22050.0
        var s := 0.0
        for h in harm.size():
            var f := 55.0 * float(h + 1) + (1.0 if h % 2 == 1 else 0.0)
            s += float(harm[h]) * sin(TAU * f * t + float(h) * 0.7)
        s = tanh(s / 2.2) * 0.55
        data.encode_s16(i * 2, int(s * 32000.0))
    return _wav(data, n)


func _make_skid_wav() -> AudioStreamWAV:
    var n := 22050
    var data := PackedByteArray()
    data.resize(n * 2)
    var rng := RandomNumberGenerator.new()
    rng.seed = 5
    for i in n:
        var t := float(i) / 22050.0
        var am := 0.65 + 0.35 * sin(TAU * 7.0 * t)
        var s := (0.6 * sin(TAU * 1250.0 * t) + 0.4 * sin(TAU * 1810.0 * t + 1.3)) * am + (rng.randf() - 0.5) * 0.5
        data.encode_s16(i * 2, int(clampf(s * 0.45, -1.0, 1.0) * 32000.0))
    return _wav(data, n)


# ---------------------------------------------------------------- input
func _read_input() -> void:
    var t := 0.0
    var b := 0.0
    var st := 0.0
    handbrake = false
    if input_enabled:
        if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
            t = 1.0
        if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
            b = 1.0
        if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
            st += 1.0
        if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
            st -= 1.0
        handbrake = Input.is_key_pressed(KEY_SPACE) or Input.is_joy_button_pressed(0, JOY_BUTTON_X)
        var jx := Input.get_joy_axis(0, JOY_AXIS_LEFT_X)
        if absf(jx) > 0.12:
            st = -jx
        var rt := Input.get_joy_axis(0, JOY_AXIS_TRIGGER_RIGHT)
        var lt := Input.get_joy_axis(0, JOY_AXIS_TRIGGER_LEFT)
        if rt > 0.05:
            t = maxf(t, rt)
        if lt > 0.05:
            b = maxf(b, lt)
    throttle_in = t
    brake_in = b
    steer_in = st


# ---------------------------------------------------------------- physics
func _physics_process(dt: float) -> void:
    _read_input()
    throttle = move_toward(throttle, throttle_in, dt * 5.0)
    brake = move_toward(brake, brake_in, dt * 6.0)
    var xf := global_transform
    var up := xf.basis.y
    var fwd := -xf.basis.z
    var right := xf.basis.x
    var vel := linear_velocity
    v_long = vel.dot(fwd)
    var v_lat := vel.dot(right)
    speed = vel.length()
    slip = atan2(v_lat, absf(v_long) + 0.5)
    flipped_time = flipped_time + dt if up.y < 0.25 else 0.0
    # steering: heavy build-up, less lock at speed, gentle counter-steer assist while sliding
    var speed_f := 1.0 / (1.0 + pow(speed / 24.0, 2.0))
    var target := steer_in * MAX_STEER * speed_f
    if speed > 6.0:
        target += clampf(-slip, -0.5, 0.5) * 0.55
    target = clampf(target, -MAX_STEER, MAX_STEER)
    var rate := 2.6 if absf(target) > absf(steer) else 4.0
    steer = move_toward(steer, target, rate * dt)
    # engine / brakes
    var drive := 0.0
    var brake_f := 0.0
    if shift_cut > 0.0:
        shift_cut -= dt
    if throttle > 0.01:
        var avail := minf(MAX_DRIVE, POWER / maxf(absf(v_long), 3.5))
        if shift_cut > 0.0:
            avail *= 0.25
        if v_long > 82.0:
            avail = 0.0
        if v_long < -1.0:
            brake_f = BRAKE_FORCE * throttle
        else:
            drive = avail * throttle
    if brake > 0.01:
        if v_long > 1.5:
            brake_f = BRAKE_FORCE * brake
        elif input_enabled and v_long > -14.0:
            drive = -5200.0 * brake
    var m_w := mass * 0.25
    grounded_count = 0
    var slip_sum := 0.0
    var parked := speed < 1.0 and throttle < 0.05 and brake < 0.05
    for i in 4:
        var ray: RayCast3D = rays[i]
        ray.force_raycast_update()
        if not ray.is_colliding():
            last_len[i] = REST + TRAVEL
            continue
        grounded_count += 1
        var hit := ray.get_collision_point()
        var col = ray.get_collider()
        var on_road: bool = col != null and col.is_in_group("road")
        var mu := MU_ROAD
        var rr := 0.015
        if not on_road:
            mu = MU_SAND if hit.y < 2.8 else MU_GRASS
            rr = 0.09
        if parked:
            rr = 0.6
        var spring_len := clampf(ray.global_position.distance_to(hit) - WHEEL_R, 0.0, REST + TRAVEL)
        var comp_vel := (last_len[i] - spring_len) / dt
        last_len[i] = spring_len
        var f_sus := clampf(SPRING_K * (REST - spring_len) + SPRING_C * comp_vel, 0.0, 28000.0)
        var cp := hit - global_position
        apply_force(up * f_sus, cp)
        var steer_a := steer if i < 2 else 0.0
        var w_fwd := fwd.rotated(up, steer_a)
        var w_right := w_fwd.cross(up)
        var pv := vel + angular_velocity.cross(cp)
        var vx := pv.dot(w_fwd)
        var vy := pv.dot(w_right)
        var budget := mu * f_sus
        if i >= 2 and handbrake:
            budget *= 0.32
        var fx := 0.0
        if i >= 2:
            fx += drive * 0.5
        var bf := brake_f * (0.6 if i < 2 else 0.4) * 0.5
        if handbrake and i >= 2:
            bf += 9000.0
        var vcap := absf(vx) * m_w / dt
        fx -= signf(vx) * minf(bf, vcap)
        fx -= signf(vx) * minf(rr * f_sus, vcap)
        var fy := -vy * m_w * LAT_RESP
        var mag := sqrt(fx * fx + fy * fy)
        if mag > budget and mag > 0.001:
            var kk := budget / mag
            fx *= kk
            fy *= kk
            slip_sum += 0.25
        apply_force(w_fwd * fx + w_right * fy, cp + up * 0.2)
    if speed > 0.1:
        apply_central_force(-vel.normalized() * DRAG * speed * speed)
    apply_central_force(-up * DOWNFORCE * speed * speed)
    wheel_slip = lerpf(wheel_slip, minf(slip_sum, 1.0), minf(dt * 10.0, 1.0))
    _update_gear(dt)
    _update_drift(dt)
    var sl := clampf(maxf(wheel_slip, (absf(slip) - 0.15) * 2.5), 0.0, 1.0)
    if speed < 4.0 or grounded_count < 2:
        sl = 0.0
    skid_player.volume_db = lerpf(-60.0, -7.0, sl)
    for p in smoke:
        p.emitting = sl > 0.35


func _update_gear(dt: float) -> void:
    var s := absf(v_long)
    var g := 7
    for k in 7:
        if s <= GEAR_TOP[k]:
            g = k + 1
            break
    if g > gear and throttle > 0.4:
        shift_cut = 0.12
    gear = g
    var lo := 0.0
    if g > 1:
        lo = GEAR_TOP[g - 2]
    var hi: float = GEAR_TOP[g - 1]
    var target := 1100.0 + clampf((s - lo) / (hi - lo), 0.0, 1.0) * 6400.0
    if shift_cut > 0.0:
        target -= 1500.0
    rpm = lerpf(rpm, target, 1.0 - exp(-dt * 14.0))


func _update_drift(dt: float) -> void:
    var now := speed > 11.0 and absf(slip) > 0.22 and grounded_count >= 3
    if now:
        drifting = true
        drift_idle = 0.0
        drift_time += dt
        drift_mult = minf(1.0 + floorf(drift_time / 2.0) * 0.5, 5.0)
        drift_score += dt * speed * absf(slip) * 30.0
    elif drift_score > 0.0:
        drifting = false
        drift_idle += dt
        if drift_idle > 1.1:
            var pts := int(drift_score * drift_mult)
            total_skill += pts
            drift_banked.emit(pts)
            drift_score = 0.0
            drift_time = 0.0
            drift_mult = 1.0
    else:
        drifting = false


func _on_hit(body: Node) -> void:
    if drift_score > 0.0 and not body.is_in_group("ground"):
        drift_score = 0.0
        drift_time = 0.0
        drift_mult = 1.0
        drift_lost.emit()


func _process(dt: float) -> void:
    spin = fmod(spin + v_long / wheel_radius_vis * dt, TAU)
    if front_pivot != null:
        front_pivot.rotation = Vector3(-spin, steer * 0.5, 0.0)
    if rear_pivot != null:
        rear_pivot.rotation = Vector3(-spin, 0.0, 0.0)
    engine_player.pitch_scale = clampf(0.55 + rpm / 1000.0 * 0.42, 0.3, 3.8)
    engine_player.volume_db = lerpf(-15.0, -3.0, clampf(throttle * 0.7 + rpm / 9000.0 * 0.5, 0.0, 1.0))


func place_at(pos: Vector3, dir: Vector3) -> void:
    var d := Vector3(dir.x, 0.0, dir.z).normalized()
    global_transform = Transform3D(Basis.looking_at(d, Vector3.UP), pos)
    linear_velocity = Vector3.ZERO
    angular_velocity = Vector3.ZERO
    steer = 0.0
    flipped_time = 0.0
    drift_score = 0.0
    drift_time = 0.0
    drift_mult = 1.0
