extends Node3D
# Entry point: lighting + post-processing, loading screen, spawns the world, car, camera, HUD and race.
# Keys: T time of day | F1 graphics quality | R respawn | ENTER race | C camera | H hide HUD

const WorldScript = preload("res://scripts/world.gd")
const CarScript = preload("res://scripts/car.gd")
const CamScript = preload("res://scripts/cam.gd")
const HudScript = preload("res://scripts/hud.gd")
const RaceScript = preload("res://scripts/race.gd")

const QUALITY_NAMES = ["Low", "Medium", "High", "Ultra"]
const TODS = [
    {"name": "Morning", "elev": 22.0, "az": 50.0, "col": Color(1.0, 0.88, 0.72), "e": 2.2, "top": Color(0.22, 0.45, 0.82), "hor": Color(0.78, 0.80, 0.82), "fog": Color(0.72, 0.77, 0.84), "amb": 1.0, "cloud": Color(1.0, 0.97, 0.95), "lights": false},
    {"name": "Midday", "elev": 62.0, "az": 20.0, "col": Color(1.0, 0.97, 0.92), "e": 2.8, "top": Color(0.16, 0.38, 0.80), "hor": Color(0.65, 0.78, 0.92), "fog": Color(0.66, 0.76, 0.88), "amb": 1.1, "cloud": Color(1.0, 1.0, 1.0), "lights": false},
    {"name": "Sunset", "elev": 6.0, "az": 250.0, "col": Color(1.0, 0.55, 0.25), "e": 2.4, "top": Color(0.18, 0.24, 0.50), "hor": Color(1.0, 0.55, 0.32), "fog": Color(0.95, 0.62, 0.45), "amb": 0.8, "cloud": Color(1.0, 0.62, 0.45), "lights": false},
    {"name": "Night", "elev": 38.0, "az": 200.0, "col": Color(0.45, 0.55, 0.90), "e": 0.35, "top": Color(0.01, 0.02, 0.07), "hor": Color(0.05, 0.07, 0.15), "fog": Color(0.04, 0.06, 0.12), "amb": 0.45, "cloud": Color(0.12, 0.14, 0.22), "lights": true},
]

var world
var car
var cam
var hud
var race
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var cloud_mat: StandardMaterial3D
var cloud_mesh: MeshInstance3D
var fx_mat: ShaderMaterial
var tod := 2
var quality := 2
var ui: CanvasLayer
var overlay: Control
var bar: ProgressBar
var msg_label: Label
var go_label: Label
var keys_label: Label
var waiting := false
var cull_t := 0.0
var settings := ConfigFile.new()


func _ready() -> void:
    if settings.load("user://settings.cfg") == OK:
        quality = clampi(int(settings.get_value("video", "quality", 2)), 0, 3)
    _build_environment()
    _build_loading_ui()
    await get_tree().process_frame
    world = WorldScript.new()
    add_child(world)
    await world.build(_on_progress, quality)
    _on_progress(0.86, "Tuning the McLaren")
    await get_tree().process_frame
    car = CarScript.new()
    add_child(car)
    car.place_at(world.road_pts[0] + Vector3(0.0, 0.9, 0.0), world.road_dirs[0])
    cam = CamScript.new()
    cam.target = car
    cam.world = world
    cam.far = 9000.0
    cam.near = 0.12
    cam.fov = 68.0
    add_child(cam)
    cam.global_position = car.global_position + Vector3(0.0, 3.0, 8.0)
    cam.make_current()
    _build_post_fx()
    var layer := CanvasLayer.new()
    layer.layer = 10
    add_child(layer)
    hud = HudScript.new()
    layer.add_child(hud)
    hud.car = car
    hud.cam = cam
    hud.setup(world)
    race = RaceScript.new()
    add_child(race)
    race.setup(world, car)
    hud.race = race
    race.message.connect(hud.show_toast)
    cam.view_changed.connect(hud.show_toast)
    car.drift_banked.connect(hud.show_bank)
    _apply_tod(tod)
    _apply_quality(quality)
    _on_progress(1.0, "Ready")
    keys_label.visible = true
    go_label.visible = true
    waiting = true


func _on_progress(v: float, text: String) -> void:
    bar.value = v * 100.0
    msg_label.text = "%s   %d%%" % [text, int(v * 100.0)]


# ---------------------------------------------------------------- environment / look
func _build_environment() -> void:
    env = Environment.new()
    sky_mat = ProceduralSkyMaterial.new()
    sky_mat.sky_curve = 0.18
    sky_mat.ground_curve = 0.02
    sky_mat.sun_angle_max = 28.0
    sky_mat.sun_curve = 0.12
    var sky := Sky.new()
    sky.sky_material = sky_mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.tonemap_white = 6.0
    env.fog_enabled = true
    env.fog_density = 0.0009
    env.fog_aerial_perspective = 0.35
    env.fog_sky_affect = 0.35
    env.ssao_radius = 2.0
    env.ssao_intensity = 2.2
    env.ssao_power = 1.6
    env.ssr_max_steps = 64
    env.ssr_fade_in = 0.15
    env.ssr_fade_out = 2.0
    env.ssr_depth_tolerance = 0.2
    env.glow_intensity = 0.7
    env.glow_strength = 1.0
    env.glow_bloom = 0.05
    env.glow_hdr_threshold = 1.0
    env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
    env.adjustment_enabled = true
    env.adjustment_contrast = 1.08
    env.adjustment_saturation = 1.12
    env.volumetric_fog_density = 0.006
    env.volumetric_fog_albedo = Color(1.0, 0.93, 0.85)
    env.volumetric_fog_length = 180.0
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    sun = DirectionalLight3D.new()
    sun.shadow_enabled = true
    sun.directional_shadow_blend_splits = true
    sun.shadow_normal_bias = 1.2
    sun.shadow_blur = 1.2
    add_child(sun)
    # cloud layer that follows the car
    var pm := PlaneMesh.new()
    pm.size = Vector2(9000.0, 9000.0)
    cloud_mat = StandardMaterial3D.new()
    cloud_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    cloud_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    cloud_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    cloud_mat.albedo_texture = load("res://assets/textures/clouds.png")
    cloud_mat.uv1_scale = Vector3(5.0, 5.0, 1.0)
    pm.material = cloud_mat
    cloud_mesh = MeshInstance3D.new()
    cloud_mesh.mesh = pm
    cloud_mesh.position = Vector3(0.0, 650.0, 0.0)
    cloud_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(cloud_mesh)


func _build_post_fx() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 1
    add_child(layer)
    var rect := ColorRect.new()
    rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fx_mat = ShaderMaterial.new()
    fx_mat.shader = load("res://assets/shaders/speedfx.gdshader")
    rect.material = fx_mat
    layer.add_child(rect)


func _apply_tod(i: int) -> void:
    var p: Dictionary = TODS[i]
    sun.rotation_degrees = Vector3(-float(p["elev"]), float(p["az"]), 0.0)
    sun.light_color = p["col"]
    sun.light_energy = float(p["e"])
    sky_mat.sky_top_color = p["top"]
    sky_mat.sky_horizon_color = p["hor"]
    sky_mat.ground_horizon_color = p["hor"]
    var top: Color = p["top"]
    sky_mat.ground_bottom_color = top.darkened(0.5)
    env.fog_light_color = p["fog"]
    env.ambient_light_energy = float(p["amb"])
    var cc: Color = p["cloud"]
    cloud_mat.albedo_color = Color(cc.r, cc.g, cc.b, 0.9)
    if car != null:
        car.set_headlights(bool(p["lights"]))


func _apply_quality(q: int) -> void:
    quality = q
    var vp := get_viewport()
    vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X, Viewport.MSAA_4X][q]
    vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if q >= 1 else Viewport.SCREEN_SPACE_AA_DISABLED
    vp.use_debanding = true
    env.ssao_enabled = q >= 2
    env.ssr_enabled = q >= 3
    env.glow_enabled = q >= 1
    env.volumetric_fog_enabled = q >= 3
    sun.directional_shadow_max_distance = [120.0, 200.0, 320.0, 450.0][q]
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS if q < 2 else DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
    RenderingServer.directional_shadow_atlas_set_size([1024, 2048, 4096, 8192][q], true)
    if cam != null:
        if q >= 3:
            var attrs := CameraAttributesPractical.new()
            attrs.dof_blur_far_enabled = true
            attrs.dof_blur_far_distance = 160.0
            attrs.dof_blur_far_transition = 220.0
            attrs.dof_blur_amount = 0.05
            cam.attributes = attrs
        else:
            cam.attributes = null
    settings.set_value("video", "quality", q)
    settings.save("user://settings.cfg")


# ---------------------------------------------------------------- loading screen
func _label(text: String, fsize: int, col: Color, parent: Node) -> Label:
    var l := Label.new()
    l.text = text
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", fsize)
    l.add_theme_color_override("font_color", col)
    parent.add_child(l)
    return l


func _build_loading_ui() -> void:
    ui = CanvasLayer.new()
    ui.layer = 100
    add_child(ui)
    overlay = Control.new()
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(overlay)
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(0.09, 0.15, 0.26), Color(0.015, 0.025, 0.05)])
    g.offsets = PackedFloat32Array([0.0, 1.0])
    var gt := GradientTexture2D.new()
    gt.gradient = g
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.4)
    gt.fill_to = Vector2(1.0, 1.0)
    gt.width = 256
    gt.height = 256
    var bg := TextureRect.new()
    bg.texture = gt
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_SCALE
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(bg)
    var box := VBoxContainer.new()
    box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.add_theme_constant_override("separation", 10)
    overlay.add_child(box)
    _label("OPEN WORLD DRIVING", 15, Color(0.5, 0.66, 0.9), box)
    _label("SILVER LAKE", 96, Color(1, 1, 1), box)
    _label("McLAREN 720S  -  ISLAND CIRCUIT", 17, Color(1, 1, 1, 0.7), box)
    var sp := Control.new()
    sp.custom_minimum_size = Vector2(0, 26)
    box.add_child(sp)
    bar = ProgressBar.new()
    bar.custom_minimum_size = Vector2(480, 6)
    bar.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
    bar.show_percentage = false
    bar.max_value = 100.0
    var fill := StyleBoxFlat.new()
    fill.bg_color = Color(0.45, 0.72, 1.0)
    var back := StyleBoxFlat.new()
    back.bg_color = Color(1, 1, 1, 0.12)
    bar.add_theme_stylebox_override("fill", fill)
    bar.add_theme_stylebox_override("background", back)
    box.add_child(bar)
    msg_label = _label("Starting engine", 16, Color(1, 1, 1, 0.8), box)
    go_label = _label("PRESS ANY KEY TO DRIVE", 22, Color(1.0, 0.85, 0.3), box)
    go_label.visible = false
    keys_label = _label("W A S D / arrows  drive      SPACE  handbrake      C  camera      T  time of day\nR  respawn      ENTER  start race      F1  graphics quality      H  hide HUD      drag mouse  look around", 15, Color(1, 1, 1, 0.8), box)
    keys_label.visible = false
    var cr := _label("Car \"2017 Mclaren 720s\" by _Sheep19  -  \"Low Poly Forest Tree Pack\" by 99.Miles  -  \"Tree low poly\" by 00amza  -  all CC BY 4.0", 12, Color(1, 1, 1, 0.45), box)
    cr.add_theme_constant_override("line_spacing", 4)


# ---------------------------------------------------------------- input / loop
func _input(event: InputEvent) -> void:
    if waiting and ((event is InputEventKey and event.pressed and not event.echo) or (event is InputEventMouseButton and event.pressed)):
        waiting = false
        car.input_enabled = true
        var tw := create_tween()
        tw.tween_property(overlay, "modulate:a", 0.0, 0.8)
        tw.tween_callback(ui.queue_free)
        hud.show_toast("Welcome to Silver Lake  -  press ENTER to start a race")
        get_viewport().set_input_as_handled()


func _unhandled_input(event: InputEvent) -> void:
    if car == null or waiting:
        return
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_T:
                tod = (tod + 1) % TODS.size()
                _apply_tod(tod)
                hud.show_toast(TODS[tod]["name"])
            KEY_R:
                _respawn()
            KEY_ENTER, KEY_KP_ENTER:
                if race.active:
                    race.stop()
                    hud.show_toast("Race cancelled")
                else:
                    race.start()
            KEY_F1:
                _apply_quality((quality + 1) % 4)
                hud.show_toast("Graphics: %s  (scenery density changes on next launch)" % QUALITY_NAMES[quality])
            KEY_H:
                hud.visible = not hud.visible


func _respawn() -> void:
    var k: int = world.nearest_road_index(car.global_position)
    car.place_at(world.road_pts[k] + Vector3(0.0, 0.9, 0.0), world.road_dirs[k])


func _process(dt: float) -> void:
    if car == null:
        return
    var cp: Vector3 = car.global_position
    cull_t -= dt
    if cull_t <= 0.0:
        cull_t = 0.25
        world.update_culling(cp)
    if not waiting and (car.flipped_time > 2.5 or cp.y < -0.3 or Vector2(cp.x, cp.z).length() > 790.0):
        _respawn()
        hud.show_toast("Back on the road")
    cloud_mesh.global_position = Vector3(cp.x, 650.0, cp.z)
    cloud_mat.uv1_offset = Vector3(cp.x / 9000.0 * 5.0 + Time.get_ticks_msec() * 0.0000012, cp.z / 9000.0 * 5.0, 0.0)
    if fx_mat != null:
        fx_mat.set_shader_parameter("strength", clampf((car.speed - 30.0) / 60.0, 0.0, 1.0) * 0.06)
