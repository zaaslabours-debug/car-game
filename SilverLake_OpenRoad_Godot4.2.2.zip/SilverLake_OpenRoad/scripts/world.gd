extends Node3D
# Procedural island: central lake, looping road, and forest / bushes / rocks taken straight
# from your original GLB files (nothing is re-compressed or reduced).

const GRID := 256            # terrain cells per side
const CELL := 6.25           # metres per cell  (GRID * CELL = 1600 m)
const HALF := 800.0
const ROAD_W := 12.0
const ROAD_N := 900          # road sample points around the loop
const CHUNKS := 4            # scenery blocks that are culled by distance
const TREE_COUNT := 520
const BUSH_COUNT := 460
const ROCK_COUNT := 280
const PACK_PATH := "res://assets/low_poly_forest_tree_pack.glb"
const SINGLE_PATH := "res://assets/tree_low_poly_lowpoly.glb"
const TEX := "res://assets/textures/"

var noise := FastNoiseLite.new()
var rng := RandomNumberGenerator.new()
var heights := PackedFloat32Array()
var road_pts := PackedVector3Array()
var road_dirs := PackedVector3Array()
var road_grid := {}
var chunk_nodes: Array = []
var chunk_centers: Array = []
var view_dist := 750.0
var density := 1.0
var tree_shadows := true
var road_mat: ShaderMaterial


func build(progress: Callable, quality: int) -> void:
    density = [0.45, 0.75, 1.0, 1.4][quality]
    view_dist = [450.0, 600.0, 750.0, 950.0][quality]
    tree_shadows = quality >= 2
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    noise.frequency = 0.0016
    noise.fractal_octaves = 5
    noise.seed = 1337
    rng.seed = 7
    progress.call(0.05, "Surveying the road")
    await get_tree().process_frame
    _make_road()
    progress.call(0.12, "Sculpting the island")
    await get_tree().process_frame
    _make_terrain()
    progress.call(0.38, "Paving the asphalt")
    await get_tree().process_frame
    _make_road_mesh()
    _make_water()
    progress.call(0.5, "Planting the forest")
    await get_tree().process_frame
    _make_scenery()
    progress.call(0.82, "Final touches")
    await get_tree().process_frame


# ---------------------------------------------------------------- helpers
func _tex(file: String) -> Texture2D:
    return load(TEX + file) as Texture2D


func road_dist(x: float, z: float) -> float:
    var cx := int(floor(x / 40.0))
    var cz := int(floor(z / 40.0))
    var best := 1.0e9
    for dz in range(-1, 2):
        for dx in range(-1, 2):
            var key := Vector2i(cx + dx, cz + dz)
            if road_grid.has(key):
                for idx in road_grid[key]:
                    var p := road_pts[idx]
                    var d := Vector2(x - p.x, z - p.z).length()
                    if d < best:
                        best = d
    return best


func nearest_road_index(pos: Vector3) -> int:
    var best := 0
    var bd := 1.0e12
    for k in ROAD_N:
        var p := road_pts[k]
        var d := (p.x - pos.x) * (p.x - pos.x) + (p.z - pos.z) * (p.z - pos.z)
        if d < bd:
            bd = d
            best = k
    return best


func height_at(x: float, z: float) -> float:
    var fx := (x + HALF) / CELL
    var fz := (z + HALF) / CELL
    var i := clampi(int(floor(fx)), 0, GRID - 1)
    var j := clampi(int(floor(fz)), 0, GRID - 1)
    var tx := clampf(fx - float(i), 0.0, 1.0)
    var tz := clampf(fz - float(j), 0.0, 1.0)
    var n := GRID + 1
    var h00 := heights[j * n + i]
    var h10 := heights[j * n + i + 1]
    var h01 := heights[(j + 1) * n + i]
    var h11 := heights[(j + 1) * n + i + 1]
    return lerpf(lerpf(h00, h10, tx), lerpf(h01, h11, tx), tz)


func update_culling(pos: Vector3) -> void:
    var p := Vector3(pos.x, 0.0, pos.z)
    for i in chunk_nodes.size():
        chunk_nodes[i].visible = chunk_centers[i].distance_to(p) < view_dist


# ---------------------------------------------------------------- road centre line
func _make_road() -> void:
    road_pts.clear()
    for k in ROAD_N:
        var a := TAU * float(k) / float(ROAD_N)
        var r := 430.0 + 120.0 * sin(2.0 * a + 1.0) + 70.0 * sin(3.0 * a + 0.3) + 30.0 * sin(5.0 * a) + 14.0 * sin(7.0 * a + 2.0)
        var h := 28.0 + 11.0 * sin(3.0 * a + 0.7) + 8.0 * sin(5.0 * a + 2.0) + 5.0 * sin(2.0 * a)
        road_pts.append(Vector3(cos(a) * r, h, sin(a) * r))
    road_dirs.resize(ROAD_N)
    for k in ROAD_N:
        var nxt := road_pts[(k + 1) % ROAD_N]
        var prv := road_pts[(k - 1 + ROAD_N) % ROAD_N]
        road_dirs[k] = Vector3(nxt.x - prv.x, 0.0, nxt.z - prv.z).normalized()
    road_grid.clear()
    for k in ROAD_N:
        var p := road_pts[k]
        var key := Vector2i(int(floor(p.x / 40.0)), int(floor(p.z / 40.0)))
        if not road_grid.has(key):
            road_grid[key] = []
        road_grid[key].append(k)


# ---------------------------------------------------------------- terrain
func _make_terrain() -> void:
    var n := GRID + 1
    var rd := PackedFloat32Array()
    rd.resize(n * n)
    rd.fill(1.0e9)
    var rh := PackedFloat32Array()
    rh.resize(n * n)
    var reach := int(ceil((ROAD_W * 0.5 + 52.0) / CELL))
    for p in road_pts:
        var ci := int(round((p.x + HALF) / CELL))
        var cj := int(round((p.z + HALF) / CELL))
        for dj in range(-reach, reach + 1):
            for di in range(-reach, reach + 1):
                var i := ci + di
                var j := cj + dj
                if i < 0 or j < 0 or i >= n or j >= n:
                    continue
                var d := Vector2(float(i) * CELL - HALF - p.x, float(j) * CELL - HALF - p.z).length()
                var idx := j * n + i
                if d < rd[idx]:
                    rd[idx] = d
                    rh[idx] = p.y
    heights.resize(n * n)
    for j in n:
        for i in n:
            var x := float(i) * CELL - HALF
            var z := float(j) * CELL - HALF
            var dc := sqrt(x * x + z * z)
            var h := 22.0 + noise.get_noise_2d(x, z) * 30.0 + noise.get_noise_2d(x * 4.0 + 90.0, z * 4.0) * 1.6
            h -= 52.0 * exp(-pow(dc / 190.0, 2.0))
            h -= 70.0 * smoothstep(600.0, 790.0, dc)
            var idx := j * n + i
            var w := 1.0 - smoothstep(ROAD_W * 0.5 + 3.0, ROAD_W * 0.5 + 46.0, rd[idx])
            heights[idx] = lerpf(h, rh[idx] - 0.05, w)
    var verts := PackedVector3Array()
    var norms := PackedVector3Array()
    var cols := PackedColorArray()
    var uvs := PackedVector2Array()
    verts.resize(n * n)
    norms.resize(n * n)
    cols.resize(n * n)
    uvs.resize(n * n)
    for j in n:
        for i in n:
            var idx := j * n + i
            var x := float(i) * CELL - HALF
            var z := float(j) * CELL - HALF
            var hl := heights[j * n + maxi(i - 1, 0)]
            var hr := heights[j * n + mini(i + 1, n - 1)]
            var hd := heights[maxi(j - 1, 0) * n + i]
            var hu := heights[mini(j + 1, n - 1) * n + i]
            var nm := Vector3(hl - hr, 2.0 * CELL, hd - hu).normalized()
            var tint := noise.get_noise_2d(x * 2.5 + 40.0, z * 2.5) * 0.5 + 0.5
            var macro := lerpf(0.66, 1.0, tint)
            var dirt := 1.0 - smoothstep(ROAD_W * 0.5 + 2.0, ROAD_W * 0.5 + 9.0, rd[idx])
            verts[idx] = Vector3(x, heights[idx], z)
            norms[idx] = nm
            cols[idx] = Color(macro, macro, macro * 0.96, dirt)
            uvs[idx] = Vector2(x / 14.0, z / 14.0)
    var idxs := PackedInt32Array()
    for j in GRID:
        for i in GRID:
            var a := j * n + i
            var c2 := a + n
            idxs.append_array(PackedInt32Array([a, a + 1, c2 + 1, a, c2 + 1, c2]))
    var arr := []
    arr.resize(Mesh.ARRAY_MAX)
    arr[Mesh.ARRAY_VERTEX] = verts
    arr[Mesh.ARRAY_NORMAL] = norms
    arr[Mesh.ARRAY_COLOR] = cols
    arr[Mesh.ARRAY_TEX_UV] = uvs
    arr[Mesh.ARRAY_INDEX] = idxs
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
    var mat := ShaderMaterial.new()
    mat.shader = load("res://assets/shaders/terrain.gdshader")
    mat.set_shader_parameter("grass_a", _tex("grass_a.jpg"))
    mat.set_shader_parameter("grass_n", _tex("grass_n.png"))
    mat.set_shader_parameter("rock_a", _tex("rock_a.jpg"))
    mat.set_shader_parameter("rock_n", _tex("rock_n.png"))
    mat.set_shader_parameter("sand_a", _tex("sand_a.jpg"))
    mat.set_shader_parameter("sand_n", _tex("sand_n.png"))
    mesh.surface_set_material(0, mat)
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    add_child(mi)
    var body := StaticBody3D.new()
    body.add_to_group("ground")
    var cs := CollisionShape3D.new()
    cs.shape = mesh.create_trimesh_shape()
    body.add_child(cs)
    add_child(body)


# ---------------------------------------------------------------- road ribbon
func _make_road_mesh() -> void:
    var total := 0.0
    for k in ROAD_N:
        var a := road_pts[k]
        var b := road_pts[(k + 1) % ROAD_N]
        total += Vector2(b.x - a.x, b.z - a.z).length()
    var vscale := floorf(total / 12.0) / total
    var verts := PackedVector3Array()
    var uvs := PackedVector2Array()
    var norms := PackedVector3Array()
    var idxs := PackedInt32Array()
    var s := 0.0
    for k in ROAD_N + 1:
        var kk := k % ROAD_N
        var p := road_pts[kk]
        var right := road_dirs[kk].cross(Vector3.UP)
        var y := p.y + 0.12
        verts.append(Vector3(p.x - right.x * ROAD_W * 0.5, y, p.z - right.z * ROAD_W * 0.5))
        verts.append(Vector3(p.x + right.x * ROAD_W * 0.5, y, p.z + right.z * ROAD_W * 0.5))
        uvs.append(Vector2(0.0, s * vscale))
        uvs.append(Vector2(1.0, s * vscale))
        norms.append(Vector3.UP)
        norms.append(Vector3.UP)
        if k < ROAD_N:
            var nx := road_pts[(k + 1) % ROAD_N]
            s += Vector2(nx.x - p.x, nx.z - p.z).length()
    for k in ROAD_N:
        var l0 := k * 2
        idxs.append_array(PackedInt32Array([l0, l0 + 2, l0 + 3, l0, l0 + 3, l0 + 1]))
    var arr := []
    arr.resize(Mesh.ARRAY_MAX)
    arr[Mesh.ARRAY_VERTEX] = verts
    arr[Mesh.ARRAY_NORMAL] = norms
    arr[Mesh.ARRAY_TEX_UV] = uvs
    arr[Mesh.ARRAY_INDEX] = idxs
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
    road_mat = ShaderMaterial.new()
    road_mat.shader = load("res://assets/shaders/road.gdshader")
    road_mat.set_shader_parameter("asph_a", _tex("asphalt_a.jpg"))
    road_mat.set_shader_parameter("asph_n", _tex("asphalt_n.png"))
    mesh.surface_set_material(0, road_mat)
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    add_child(mi)
    var body := StaticBody3D.new()
    body.add_to_group("road")
    body.add_to_group("ground")
    var cs := CollisionShape3D.new()
    cs.shape = mesh.create_trimesh_shape()
    body.add_child(cs)
    add_child(body)


func _make_water() -> void:
    var pm := PlaneMesh.new()
    pm.size = Vector2(5000.0, 5000.0)
    pm.subdivide_width = 1
    pm.subdivide_depth = 1
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.03, 0.2, 0.3, 0.88)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.roughness = 0.04
    mat.metallic = 0.15
    mat.metallic_specular = 0.9
    pm.material = mat
    var mi := MeshInstance3D.new()
    mi.mesh = pm
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)


# ---------------------------------------------------------------- scenery from the original GLBs
func _rel_xf(n: Node3D, root: Node) -> Transform3D:
    var t := n.transform
    var p := n.get_parent()
    while p != null and p != root:
        if p is Node3D:
            t = (p as Node3D).transform * t
        p = p.get_parent()
    return t


func _collect(path: String) -> Array:
    var out: Array = []
    var res = load(path)
    if res == null:
        push_warning("Could not load " + path)
        return out
    var root: Node = res.instantiate()
    for mi in root.find_children("*", "MeshInstance3D", true, false):
        if mi.mesh == null:
            continue
        var xf: Transform3D = _rel_xf(mi, root)
        var mname := ""
        var m = mi.mesh.surface_get_material(0)
        if m != null:
            mname = String(m.resource_name)
        var box: AABB = xf * mi.mesh.get_aabb()
        out.append({"mesh": mi.mesh, "xf": xf, "aabb": box, "mat": mname})
    root.free()
    return out


# Keeps the original textures; only switches blended foliage to alpha-scissor so it sorts
# correctly, and removes any "shiny" metal that the importer would otherwise add.
func _fix_mesh(mesh: Mesh, cache: Dictionary) -> void:
    for s in mesh.get_surface_count():
        var m = mesh.surface_get_material(s)
        if m == null or not (m is BaseMaterial3D):
            continue
        var key: int = m.get_instance_id()
        if not cache.has(key):
            var d: BaseMaterial3D = m.duplicate()
            d.metallic = 0.0
            d.metallic_specular = 0.3
            if String(m.resource_name) == "Tree_1":
                d.transparency = BaseMaterial3D.TRANSPARENCY_DISABLED
                d.albedo_color = Color(d.albedo_color.r, d.albedo_color.g, d.albedo_color.b, 1.0)
            elif d.transparency != BaseMaterial3D.TRANSPARENCY_DISABLED:
                d.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
                d.alpha_scissor_threshold = 0.5
                d.alpha_antialiasing_mode = BaseMaterial3D.ALPHA_ANTIALIASING_ALPHA_TO_COVERAGE
                d.cull_mode = BaseMaterial3D.CULL_DISABLED
                d.roughness = 0.95
            cache[key] = d
        mesh.surface_set_material(s, cache[key])


func _union(parts: Array) -> AABB:
    var box: AABB = parts[0]["aabb"]
    for q in range(1, parts.size()):
        box = box.merge(parts[q]["aabb"])
    return box


func _make_proto(kind: String, parts: Array, out: Array) -> void:
    var box := _union(parts)
    var c := box.get_center()
    var shift := Transform3D(Basis(), Vector3(-c.x, -box.position.y, -c.z))
    var plist: Array = []
    for p in parts:
        plist.append({"mesh": p["mesh"], "base": shift * p["xf"]})
    out.append({"kind": kind, "parts": plist, "size": box.size})


func _make_scenery() -> void:
    var cache := {}
    var protos: Array = []
    var pack := _collect(PACK_PATH)
    var branches: Array = []
    var trunks: Array = []
    for e in pack:
        var mname: String = e["mat"]
        var sz: Vector3 = e["aabb"].size
        _fix_mesh(e["mesh"], cache)
        if mname == "Rocks":
            _make_proto("r", [e], protos)
        elif mname == "Background_Tree_Atlas":
            if sz.y > 15.0:
                _make_proto("t", [e], protos)
            elif sz.y > 1.5 and sz.x < 4.5:
                _make_proto("b", [e], protos)
        elif mname.begins_with("Tree_Branches"):
            branches.append(e)
        elif mname.begins_with("Tree_Trunk"):
            trunks.append(e)
    for b in branches:
        var bc: Vector3 = b["aabb"].get_center()
        for t in trunks:
            var tc: Vector3 = t["aabb"].get_center()
            if absf(bc.x - tc.x) < 3.5 and absf(bc.z - tc.z) < 3.5:
                _make_proto("t", [t, b], protos)
                break
    for e in _collect(SINGLE_PATH):
        _fix_mesh(e["mesh"], cache)
        _make_proto("t", [e], protos)
    if protos.is_empty():
        push_warning("No scenery meshes found - check the GLB files in res://assets")
        return
    var kind_ids := {"t": [], "b": [], "r": []}
    for i in protos.size():
        kind_ids[protos[i]["kind"]].append(i)
    var csize := HALF * 2.0 / float(CHUNKS)
    for cz in CHUNKS:
        for cx in CHUNKS:
            var nd := Node3D.new()
            add_child(nd)
            chunk_nodes.append(nd)
            chunk_centers.append(Vector3(-HALF + (float(cx) + 0.5) * csize, 0.0, -HALF + (float(cz) + 0.5) * csize))
    var buckets := {}
    var colliders := Node3D.new()
    add_child(colliders)
    # kind, count, min distance from road centre, min scale, max scale (relative to the asset's own size)
    var specs := [["t", int(TREE_COUNT * density), 16.0, 0.8, 1.2], ["b", int(BUSH_COUNT * density), 9.5, 0.9, 1.5], ["r", int(ROCK_COUNT * density), 9.0, 1.5, 4.0]]
    for spec in specs:
        var kind: String = spec[0]
        var want: int = spec[1]
        var dmin: float = spec[2]
        var smin: float = spec[3]
        var smax: float = spec[4]
        var ids: Array = kind_ids[kind]
        if ids.is_empty():
            continue
        var placed := 0
        var tries := 0
        while placed < want and tries < want * 14:
            tries += 1
            var x := rng.randf_range(-HALF * 0.92, HALF * 0.92)
            var z := rng.randf_range(-HALF * 0.92, HALF * 0.92)
            if rng.randf() < 0.6:
                var k := rng.randi() % ROAD_N
                var rp := road_pts[k]
                var side := road_dirs[k].cross(Vector3.UP)
                var off := rng.randf_range(dmin, dmin + 70.0)
                if rng.randf() < 0.5:
                    off = -off
                x = rp.x + side.x * off
                z = rp.z + side.z * off
            var h := height_at(x, z)
            if h < 3.0 or h > 52.0:
                continue
            var rdist := road_dist(x, z)
            if rdist < dmin:
                continue
            if kind == "t" and noise.get_noise_2d(x * 3.0 + 500.0, z * 3.0) < -0.15:
                continue
            if absf(height_at(x + 4.0, z) - height_at(x - 4.0, z)) > 5.5 or absf(height_at(x, z + 4.0) - height_at(x, z - 4.0)) > 5.5:
                continue
            var pid: int = ids[rng.randi() % ids.size()]
            var psize: Vector3 = protos[pid]["size"]
            var sc := rng.randf_range(smin, smax)
            var sx := sc * rng.randf_range(0.92, 1.1)
            var bs := Basis(Vector3.UP, rng.randf() * TAU) * Basis.from_scale(Vector3(sx, sc, sx))
            var xf := Transform3D(bs, Vector3(x, h - 0.1 * sc, z))
            var ci := clampi(int((x + HALF) / csize), 0, CHUNKS - 1) + clampi(int((z + HALF) / csize), 0, CHUNKS - 1) * CHUNKS
            var key := Vector2i(ci, pid)
            if not buckets.has(key):
                buckets[key] = []
            buckets[key].append(xf)
            placed += 1
            if rdist < 38.0 and kind != "b":
                var sb := StaticBody3D.new()
                var csh := CollisionShape3D.new()
                if kind == "t":
                    var cyl := CylinderShape3D.new()
                    cyl.radius = clampf(psize.x * sx * 0.05, 0.35, 0.9)
                    cyl.height = 6.0
                    csh.shape = cyl
                    sb.position = Vector3(x, h + 3.0, z)
                else:
                    var ball := SphereShape3D.new()
                    ball.radius = maxf(psize.x, 0.1) * sx * 0.36
                    csh.shape = ball
                    sb.position = Vector3(x, h + ball.radius * 0.4, z)
                sb.add_child(csh)
                colliders.add_child(sb)
    for key in buckets.keys():
        var list: Array = buckets[key]
        var proto: Dictionary = protos[key.y]
        for part in proto["parts"]:
            var mm := MultiMesh.new()
            mm.transform_format = MultiMesh.TRANSFORM_3D
            mm.mesh = part["mesh"]
            mm.instance_count = list.size()
            var base: Transform3D = part["base"]
            for q in list.size():
                mm.set_instance_transform(q, list[q] * base)
            var mmi := MultiMeshInstance3D.new()
            mmi.multimesh = mm
            if proto["kind"] != "t" or not tree_shadows:
                mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
            chunk_nodes[key.x].add_child(mmi)
